#!usr/bin/env python
from numpy import *
a=random.rand(1000)

print "Mean :", mean(a)
print "Variance:", var(a)
