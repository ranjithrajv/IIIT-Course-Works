#!usr/bin/env python
from numpy import *
a = [[1,2,3],[11,12,13],[21,22,23]]
print a
print "Eigan Values", linalg.eig(a)
